package com.lxy.rpc.bean;

import lombok.ToString;

@ToString(callSuper = true)
public class PingMessage extends Message {
    @Override
    public int getMessageType() {
        return PingMessage;
    }
}
