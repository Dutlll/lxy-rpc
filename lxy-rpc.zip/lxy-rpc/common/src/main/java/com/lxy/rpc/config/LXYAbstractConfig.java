package com.lxy.rpc.config;


import com.lxy.rpc.protocol.Serializer;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.concurrent.ConcurrentLinkedQueue;

public abstract class LXYAbstractConfig {


    /**
     * this is the source of local config
     */
    private static Properties properties;

    /**
     * this is the source of remote hot deploy config
     */
    private static Properties hotDeploymentConfig;

    /**
     * this queque record the components which has the effect of hot deploy
     *
     */
    private ConcurrentLinkedQueue<HotDeployment> hotDeployments = new ConcurrentLinkedQueue<>();

    protected static void setProperties(Properties properties) {
        LXYAbstractConfig.properties = properties;
    }

    protected static void setHotDeploymentConfig(Properties hotDeploymentConfig) {
        LXYAbstractConfig.hotDeploymentConfig = hotDeploymentConfig;
    }

    protected void setHotDeployments(ConcurrentLinkedQueue<HotDeployment> hotDeployments) {
        this.hotDeployments = hotDeployments;
    }

    public void registInHotDeplayQueue(HotDeployment hotDeployment){
        hotDeployments.add(hotDeployment);
    }

    public void removeInHotDeplayQueue(HotDeployment hotDeployment){
        hotDeployments.remove(hotDeployment);
    }

    /**
     * once get the hot deploy imstrument , start doHotDeploy.
     */
    public void doHotDeployAllCompomnent(){
        for (HotDeployment hotDeployment : hotDeployments){
            hotDeployment.doHotDeploy();
        }
    }

    public <T> T getProperty(String propertyName){
        final String property = properties.getProperty(propertyName);

        final Integer tryReflect;
        try{
            tryReflect = Integer.parseInt(property);
            return (T) tryReflect;
        }catch (Exception e){
        }

        final Boolean booleanFalse = false;
        final Boolean booleanTrue = true;
        if ( property.equals("true")) return (T)booleanTrue;
        else if (property.equals("false")) return (T)booleanFalse;

        return (T) properties.getProperty(propertyName);
    }

    /**
     * load local properties file
     */
    private void initProperties(){
        try (InputStream in = LXYAbstractConfig.class.getResourceAsStream("/application.properties")) {
            properties = new Properties();
            properties.load(in);
            hotDeploymentConfig = new Properties();
            hotDeploymentConfig.load(in);
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }






    static {
        try (InputStream in = LXYAbstractConfig.class.getResourceAsStream("/application.properties")) {
            properties = new Properties();
            properties.load(in);
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }
    public static int getServerPort() {
        String value = properties.getProperty("server.port");
        if(value == null) {
            return 8080;
        } else {
            return Integer.parseInt(value);
        }
    }
    public static Serializer.Algorithm getSerializerAlgorithm() {
        String value = properties.getProperty("serializer.algorithm");
        if(value == null) {
            return Serializer.Algorithm.Java;
        } else {
            return Serializer.Algorithm.valueOf(value);
        }
    }


}