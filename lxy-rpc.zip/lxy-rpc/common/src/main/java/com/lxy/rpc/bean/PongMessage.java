package com.lxy.rpc.bean;


public class PongMessage extends Message {
    @Override
    public int getMessageType() {
        return PongMessage;
    }
}
