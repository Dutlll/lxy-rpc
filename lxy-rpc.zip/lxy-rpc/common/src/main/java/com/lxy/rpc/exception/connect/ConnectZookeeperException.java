package com.lxy.rpc.exception.connect;

public class ConnectZookeeperException extends Exception{
    public static void throwException() throws Exception{
        throw new Exception();
    }

}
