package com.lxy.rpc.config;

import org.springframework.stereotype.Component;

@Component
public class LXYHotDeploymentConfig extends LXYAbstractConfig {

}
