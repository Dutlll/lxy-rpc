package com.lxy.rpc.constenum;

public enum ConstEnum {
    zookeeper_curator_sessionTimeoutMs("zookeeper.curator.sessionTimeoutMs"),
    zookeeper_curator_connectionTimeoutMs("zookeeper.curator.connectionTimeoutMs"),
    zookeeper_curator_baseSleepTimeMs("zookeeper.curator.baseSleepTimeMs"),
    zookeeper_curator_maxRetries("zookeeper.curator.maxRetries"),
    zookeeper_curator_connectString("zookeeper.curator.connectString"),
    remoteip_choice_strategy("remoteip.choice.strategy"),
    service_discover_class("service.discover.class"),
    zookeeper_getstrategy("zookeeper.getstrategy"),

//    #远程服务发现，心跳检测间隔时间(s)
    service_discover_heartbeat_initialDaley("service.discover.heartbeat_initialDaley"),
//            #远程服务发现，心跳检测间隔初始延时时间(s)
    service_discover_heartbeat_period("service.discover.heartbeat_period"),


    //#远程服务调用响应处理策略 RPCCallbackInterface的子类
    service_discover_RPCCallbackClass("service.discover.RPCCallbackClass"),

    //service.request.RPCRequestPolicy
    service_request_RPCRequestPolicy("service.request.RPCRequestPolicy"),

    service_regist_ip("service.regist.ip"),
    service_regist_port("service.regist.port"),

    service_regist_serviceName("service.regist.serviceName"),


    service_heartbeat_readerIdleIimeSeconds("service.heartbeat.readerIdleIimeSeconds"),
    service_heartbeat_writeIdleTimeSeconds("service.heartbeat.writeIdleTimeSeconds"),
    service_heartbeat_alldleTimeSeconds("service.heartbeat.alldleTimeSeconds");


    private String value;
    public void setValue(String value){
        value = value;
    }
    public String getName(){
        return value;
    }
    private ConstEnum(String value){
        this.value=value;
    }
}
