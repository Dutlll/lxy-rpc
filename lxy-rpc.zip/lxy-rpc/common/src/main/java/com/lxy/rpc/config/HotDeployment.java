package com.lxy.rpc.config;

/**
 * for the instance which use LXTConfig(com.lxy.rpc.config.LXTConfig) as the Config source
 */
public interface HotDeployment {

    /**
     * in order to support config for our project,
     * we shuold identify a interface which will be called after hot config
     */
    public void doHotDeploy();

    /**
     * regist self in config queue, for hot deploy
     */
    public void doRegistInConfig();
}
