package com.lxy.rpc.service;

import com.lxy.rpc.annotation.LXYServiceComsumer;

@LXYServiceComsumer(tarServiceName = "/test")
public interface HelloService {
    String sayHello(String name);
}
