package com.lxy.rpc.exception.connect;

public enum ConnectServiceRegisterException{
    ConnectZookeeperException{
//        RuntimeErrorException
    }
}
