package com.lxy.rpc.exception;

public class LXYRpcConfigException  extends LXYRpcException {

    public LXYRpcConfigException(String desc) {
        super(LXYRpcErrorType.CLIENT_ROUTER, desc);
    }

    public LXYRpcConfigException(String desc, Throwable t) {
        super(LXYRpcErrorType.CLIENT_ROUTER, desc, t);
    }
}