package com.lxy.rpc.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(
        prefix = "service.discover"
)
@Setter
@Getter
public class ServiceDiscoverProperties {
    //远程服务发现，心跳检测间隔时间(s)
    private Integer heartbeat_initialDaley=3;

    //远程服务发现，心跳检测间隔初始延时时间(s)
    private Integer heartbeat_period=3;
}
