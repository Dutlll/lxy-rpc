package com.lxy.rpc.exception.connect;

public enum LXYExceptionEnum {
    ConnectZookeeperException("CONNECT TO SERVICE REGISTER : connect to zookeeper fail...");
    private String desc;
    LXYExceptionEnum(String desc){
        this.desc = desc;
    }

    public static void main(String[] args) {
        final LXYExceptionEnum connectZookeeperException = LXYExceptionEnum.ConnectZookeeperException;
        System.out.println(connectZookeeperException);
        System.out.println(connectZookeeperException == LXYExceptionEnum.ConnectZookeeperException);
    }
}
