package java.com.lxy.rpc.server.service;

public interface HelloService {
    String sayHello(String name);
}
