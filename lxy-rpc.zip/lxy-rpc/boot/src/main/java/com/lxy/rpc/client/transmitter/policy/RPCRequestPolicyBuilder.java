package com.lxy.rpc.client.transmitter.policy;

import com.lxy.rpc.client.transmitter.policy.RPCRequestPolicy;

public abstract class RPCRequestPolicyBuilder {

    public abstract RPCRequestPolicy getRPCRequestPolicy();


}
