//import cn.itcast.server.service.HelloService;
import com.lxy.rpc.LxyRpcApplication;
import com.lxy.rpc.client.proxyer.StandardAbstractRPCProxyer;
import com.lxy.rpc.config.ServiceDiscoverProperties;
import com.lxy.rpc.service.HelloService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(
        classes = LxyRpcApplication.class)
@AutoConfigureMockMvc
@TestPropertySource(
        locations = "classpath:application.properties")
public class ATest {
    
//    @Autowired
//    private ZookeeperServiceDiscover zookeeperServiceDiscover;

    @Autowired
    private ServiceDiscoverProperties serviceDiscoverProperties;

    @Autowired
    private StandardAbstractRPCProxyer standardAbstractRPCProxyer;



    @Test
    public void  asdsa() throws InterruptedException {

        HelloService proxyObject = standardAbstractRPCProxyer.getProxyObject(HelloService.class);
        final String s = proxyObject.sayHello("1111");
        System.out.println("=======================服务返回");
        System.out.println(s);
        proxyObject.sayHello("2222");


        try {
            System.in.read();
        }catch (Exception e){
            e.printStackTrace();
        }
//        System.out.println(serviceDiscoverProperties.getHeartbeat_initialDaley());
////        final Object zookeeperServiceDiscover = this.zookeeperServiceDiscover.factory.
////                getBean("zookeeperServiceDiscover");
////        final ZookeeperServiceDiscover zookeeperServiceDiscover1 =(ZookeeperServiceDiscover) zookeeperServiceDiscover;
////        System.out.println(zookeeperServiceDiscover1.getIPGuider("/test"));
//        System.out.println("--------------------");
//        IPGuider ipGuider=null;
////        try {
////             ipGuider = this.zookeeperServiceDiscover.getIPGuider("/test");
////            System.out.println(ipGuider.toString());
////        }catch (Exception e){
////
////        }
////
////        try {
////            ipGuider = this.zookeeperServiceDiscover.getIPGuider("/test");
////            System.out.println(ipGuider.toString());
////        }catch (Exception e){
////
////        }        try {
////            ipGuider = this.zookeeperServiceDiscover.getIPGuider("/test");
////            System.out.println(ipGuider.toString());
////        }catch (Exception e){
////
////        }
////        try {
////            ipGuider = this.zookeeperServiceDiscover.getIPGuider("/test");
////            System.out.println(ipGuider.toString());
////        }catch (Exception e){
////            e.printStackTrace();
////        }
////        TimeUnit.SECONDS.sleep(10);
////        for (int i = 0;i<100;i++){
////            try {
////                ipGuider = this.zookeeperServiceDiscover.getIPGuider("/test");
////                System.out.println(ipGuider.toString());
////            }catch (Exception e){
////                e.printStackTrace();
////            }
////        }
    }
}
