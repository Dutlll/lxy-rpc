import com.lxy.rpc.annotation.LXYServiceComsumer;

@LXYServiceComsumer( tarServiceName="/test")
public interface Aaa{
    public void helle();
}